const config = {APIKEY_MAP : "90fda858df222be3db38be2784b08668"}

export default config;